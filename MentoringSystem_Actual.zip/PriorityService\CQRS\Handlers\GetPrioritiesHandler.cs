using PriorityService.CQRS.Queries;

namespace PriorityService.CQRS.Handlers;

public class GetPrioritiesHandler
{
    // Tu lógica acá
}
