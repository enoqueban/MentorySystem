namespace PriorityService.CQRS.Queries;

public class GetPrioritiesQuery
{
    // Sin propiedades por ahora
}
