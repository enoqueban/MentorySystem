namespace EvaluationService.CQRS.Queries;

public class GetEvaluationsByMentorQuery
{
    public Guid MentorId { get; set; }
}
