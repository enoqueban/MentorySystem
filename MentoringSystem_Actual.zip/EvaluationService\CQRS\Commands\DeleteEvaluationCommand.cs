namespace EvaluationService.CQRS.Commands;

public class DeleteEvaluationCommand
{
    public Guid EvaluationId { get; set; }
}
