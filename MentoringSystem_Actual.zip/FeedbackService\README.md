# FeedbackService

Serviço para gerenciamento de feedback de usuários.
