﻿namespace MentoringSystem.Shared;

public class Class1
{

}
