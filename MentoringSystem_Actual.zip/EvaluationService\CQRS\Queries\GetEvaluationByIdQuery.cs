namespace EvaluationService.CQRS.Queries;

public class GetEvaluationByIdQuery
{
    public Guid EvaluationId { get; set; }
}
