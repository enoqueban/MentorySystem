namespace EvaluationService.CQRS.Queries;

public class GetAllEvaluationsQuery { }
